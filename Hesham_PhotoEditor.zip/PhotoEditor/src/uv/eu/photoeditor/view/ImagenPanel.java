/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package uv.eu.photoeditor.view;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Stroke;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.image.BufferedImage;
import java.util.ArrayList;
import javax.swing.BorderFactory;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;
import uv.eu.photoeditor.controller.PhotoEditorController.PhotoEditorMouseListener;
import uv.eu.photoeditor.model.PhotoEditorModel;

/**
 *
 * @author hesham
 */
public class ImagenPanel extends JPanel implements MouseListener{
    private BufferedImage image;
    private ArrayList<Integer> x = new ArrayList<>();;
    private ArrayList<Integer> y = new ArrayList<>();;
    
    
    @Override
    public void paintComponent(Graphics g){
        super.paintComponent(g);
        g.drawImage(image, 2, 2, this);
    }
    
    public ImagenPanel(PhotoEditorModel model){
        image = model.getImagen();
        this.setBorder(BorderFactory.createLineBorder(Color.black,2));
        this.addMouseListener(this);
    }
    
    @Override
    public void mouseClicked(MouseEvent e) {
        Graphics g = getGraphics();
        Graphics2D g2d = (Graphics2D)g;
        
        Color color1 = Color.RED;
        Color color2 = Color.GREEN;
        GradientPaint gp = new GradientPaint(0, 0, color1, 500, 500, color2);
        g2d.setPaint(gp);
        
        if (SwingUtilities.isRightMouseButton(e)){
            int nPoints = x.size();
            int[] xArray = new int[x.size()];
            int[] yArray = new int[y.size()];
            
            for (int i=0;i<x.size();i++){
                xArray[i] = x.get(i);
                yArray[i] = y.get(i);
            }
            g2d.setStroke(new BasicStroke(20.0f));
            g.drawPolygon(xArray, yArray, nPoints);
            x.clear();
            y.clear();
        }
        else
        {
            x.add(e.getX());
            y.add(e.getY());
            g.fillOval(e.getX()-10, e.getY()-10, 20, 20);
        }
    }

    @Override
    public void mousePressed(MouseEvent e) {}
    @Override
    public void mouseReleased(MouseEvent e) {}
    @Override
    public void mouseEntered(MouseEvent e) {}
    @Override
    public void mouseExited(MouseEvent e) {}
}
