/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package uv.eu.photoeditor.view;

import java.awt.BorderLayout;
import java.awt.event.ActionListener;
import javax.swing.JFrame;
import uv.eu.photoeditor.model.PhotoEditorModel;

/**
 *
 * @author hesham
 */
public class PhotoEditorView extends JFrame{
    private PhotoEditorMenuBar menu;
    private WidthPanel top;
    public SelectPanel select;
    public ImagenPanel image;
    public StatusPanel status; 
    private static PhotoEditorModel model;
    
    public PhotoEditorView(PhotoEditorModel model){
        this.model = model;
        
        setLayout(new BorderLayout());
        
        menu = new PhotoEditorMenuBar();
        top = new WidthPanel();
        select = new SelectPanel();
        image = new ImagenPanel(model);
        status = new StatusPanel();
        
        this.setJMenuBar(menu);
        
        add(top, BorderLayout.NORTH);
        add(select, BorderLayout.WEST);
        add(image, BorderLayout.CENTER);
        add(status, BorderLayout.SOUTH);
        
        this.setSize(900,900);
        this.setVisible(true);
    }
    public void repaintImage(){
        System.out.println("The current file is: " + model.getImagenFileName());
        this.revalidate();
        this.repaint();
    }
    
    public void setActionListener(ActionListener actionListener){
        //Top Menu items
        menu.cargar.addActionListener(actionListener);
        menu.guardar.addActionListener(actionListener);
        menu.salir.addActionListener(actionListener);
        
        //Color Buttons
        for (int i=0;i<13;i++){
            select.panel1.getButton(i).addActionListener(actionListener);
        }
        for (int i=0;i<13;i++){
            select.panel2.getButton(i).addActionListener(actionListener);
        }
    }
}
